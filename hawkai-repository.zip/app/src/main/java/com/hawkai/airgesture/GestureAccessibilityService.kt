package com.hawkai.airgesture

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.AudioManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Performs the system-wide actions. Only dispatches actions; never reads screen content. */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun perform(action: Action) {
        when (action) {
            Action.NONE -> Unit
            Action.SCREENSHOT -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            Action.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            Action.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            Action.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            Action.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            Action.PAGE_NEXT -> swipe(0.80f, 0.50f, 0.20f, 0.50f)
            Action.PAGE_PREV -> swipe(0.20f, 0.50f, 0.80f, 0.50f)
            Action.SCROLL_DOWN -> swipe(0.50f, 0.70f, 0.50f, 0.30f)
            Action.SCROLL_UP -> swipe(0.50f, 0.30f, 0.50f, 0.70f)
            Action.TAP_CENTER -> tap(0.5f, 0.5f)
            Action.PLAY_PAUSE -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            }
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels * x1, dm.heightPixels * y1)
            lineTo(dm.widthPixels * x2, dm.heightPixels * y2)
        }
        dispatch(GestureDescription.StrokeDescription(path, 0, 260))
    }

    private fun tap(x: Float, y: Float) {
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * x, dm.heightPixels * y) }
        dispatch(GestureDescription.StrokeDescription(path, 0, 50))
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription) {
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
